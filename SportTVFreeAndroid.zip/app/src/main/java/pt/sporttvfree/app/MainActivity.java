package pt.sporttvfree.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(15, 15, 15);
    private final int RED = Color.rgb(229, 9, 20);
    private final int CARD = Color.rgb(35, 35, 35);

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(page);

        TextView brand = new TextView(this);
        brand.setText("SPORT TV  FREE");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(27);
        brand.setTypeface(null, Typeface.BOLD);
        page.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("O teu ponto de encontro para desporto");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(6), 0, dp(22));
        page.addView(subtitle);

        TextView section = heading("CANAIS DESPORTIVOS");
        page.addView(section);

        addChannel(page, "FIFA+", "Futebol e conteúdos oficiais da FIFA", "https://www.plus.fifa.com");
        addChannel(page, "UEFA.tv", "Conteúdos e competições selecionadas da UEFA", "https://www.uefa.tv");
        addChannel(page, "Red Bull TV", "Desportos, eventos e documentários", "https://www.redbull.com/int-en/tv");

        page.addView(heading("SPORT TV"));
        addChannel(page, "SPORT TV 1–6", "Canais sujeitos a subscrição e autenticação", "https://www.sporttv.pt");

        TextView note = new TextView(this);
        note.setText("Nota: esta aplicação não transmite nem desbloqueia canais pagos. Os botões abrem os serviços oficiais. A disponibilidade de conteúdos gratuitos pode variar por país e evento.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(12);
        note.setPadding(0, dp(18), 0, 0);
        page.addView(note);

        setContentView(scroll);
    }

    private TextView heading(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(RED);
        v.setTextSize(15);
        v.setTypeface(null, Typeface.BOLD);
        v.setPadding(0, dp(18), 0, dp(10));
        return v;
    }

    private void addChannel(LinearLayout parent, String name, String detail, String url) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackgroundColor(CARD);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.setMargins(0, 0, 0, dp(10));
        parent.addView(card, cp);

        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(null, Typeface.BOLD);
        card.addView(title);

        TextView desc = new TextView(this);
        desc.setText(detail);
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(13);
        desc.setPadding(0, dp(4), 0, dp(12));
        card.addView(desc);

        Button button = new Button(this);
        button.setText("ABRIR CANAL");
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(RED));
        button.setOnClickListener(v -> openUrl(url));
        card.addView(button);
    }

    private void openUrl(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o serviço.", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density);
    }
}
